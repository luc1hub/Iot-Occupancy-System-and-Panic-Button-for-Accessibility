#include <WiFi.h>
#include <PubSubClient.h>

// Definição dos Pinos do ESP32
const int PINO_BOTAO = 4;    // Botão de pânico
const int PINO_TRIG = 12;   // Trigger do HC-SR04
const int PINO_ECHO = 14;   // Echo do HC-SR04
const int PINO_LED = 2;     // LED de alerta (giroflex)
const int PINO_BUZZER = 13; // Buzzer de alerta

// Configurações de Rede Wi-Fi (Wokwi simula uma rede aberta sem senha)
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Configurações do Broker MQTT Público
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;

WiFiClient espClient;
PubSubClient client(espClient);

unsigned long ultimaLeitura = 0;
const long intervaloLeitura = 2000; // Intervalo de 2 segundos entre leituras

void setup() {
  Serial.begin(115200);

  // Configuração dos pinos
  pinMode(PINO_BOTAO, INPUT_PULLUP);
  pinMode(PINO_TRIG, OUTPUT);
  pinMode(PINO_ECHO, INPUT);
  pinMode(PINO_LED, OUTPUT);
  pinMode(PINO_BUZZER, OUTPUT);

  // Estado inicial desligado
  digitalWrite(PINO_LED, LOW);
  digitalWrite(PINO_BUZZER, LOW);

  // Conexão Wi-Fi e MQTT
  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
}

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Conectando-se ao Wi-Fi: ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWi-Fi conectado com sucesso!");
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Tentando conexão MQTT...");
    // Cria um ID de cliente único para a simulação
    String clientId = "ESP32Client-Wokwi-";
    clientId += String(random(0xffff), HEX);
    
    if (client.connect(clientId.c_str())) {
      Serial.println("Conectado ao Broker MQTT!");
      client.publish("sistema/acessibilidade/status", "online");
      client.subscribe("sistema/acessibilidade/comando");
    } else {
      Serial.print("falha, rc=");
      Serial.print(client.state());
      Serial.println(" tentando novamente em 2 segundos");
      delay(2000);
    }
  }
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  // 1. Verificação contínua do Botão de Pânico (Prioritário)
  verificarBotaoPanico();

  // 2. Leitura periódica do Sensor Ultrassônico a cada 2 segundos (Não bloqueante)
  unsigned long agora = millis();
  if (agora - ultimaLeitura >= intervaloLeitura) {
    ultimaLeitura = agora;
    medirOcupacaoEEnviar(agora);
  }
}

void verificarBotaoPanico() {
  // Como usamos INPUT_PULLUP, pressionado = LOW
  if (digitalRead(PINO_BOTAO) == LOW) {
    unsigned long tempoInicio = millis();

    // Aciona atuadores locais de forma instantânea
    digitalWrite(PINO_LED, HIGH);
    digitalWrite(PINO_BUZZER, HIGH);

    // Publica alerta crítico no MQTT (QoS 1 simulado)
    String payload = "{\"status\":\"ACTIVE\",\"priority\":\"HIGH\"}";
    client.publish("sistema/acessibilidade/panico", payload.c_str());

    unsigned long tempoDecorrido = millis() - tempoInicio;

    Serial.print("[TEMPO] Botão de Pânico acionado -> Latência de processamento/envio: ");
    Serial.print(tempoDecorrido);
    Serial.println(" ms");

    delay(300); // Debounce simples para evitar múltiplos disparos no clique
  } else {
    // Desliga alarme local se o botão não estiver pressionado
    digitalWrite(PINO_LED, LOW);
    digitalWrite(PINO_BUZZER, LOW);
  }
}

void medirOcupacaoEEnviar(unsigned long tempoInicio) {
  // Disparo do pulso do HC-SR04
  digitalWrite(PINO_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PINO_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PINO_TRIG, LOW);

  long duracao = pulseIn(PINO_ECHO, HIGH, 30000); // Timeout de 30ms
  long distancia = duracao * 0.034 / 2; // Conversão para cm

  unsigned long tempoFim = millis();
  unsigned long tempoSensor = tempoFim - tempoInicio;

  // Determina status de ocupação (limiar de 100 cm / 1 metro)
  bool ocupado = (distancia > 0 && distancia < 100);

  // Montagem do JSON de telemetria
  String payload = "{\"occupancy\":";
  payload += (ocupado ? "true" : "false");
  payload += ",\"distance_cm\":";
  payload += distancia;
  payload += "}";

  client.publish("sistema/acessibilidade/ocupacao", payload.c_str());

  // Exibe as medições no Monitor Serial para preencher o seu relatório
  Serial.print("[TEMPO] Sensor HC-SR04 (Leitura + Envio MQTT) -> Tempo: ");
  Serial.print(tempoSensor);
  Serial.print(" ms | Distância: ");
  Serial.print(distancia);
  Serial.println(" cm");
}